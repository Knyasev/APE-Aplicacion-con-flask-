class Error:
    error = {
        "-1": "No se encuntra rol",
        "-2": "Ya existe la cuenta",
        "-3": "No se pudo modificar persona",
        "-4": "Motivo no encontrado",
        "-5": "Cuenta no encontrada",
        "-6": "Token no existe",
        "-7": "Token no valido",
        "-8": "Persona no encontrada",

    }