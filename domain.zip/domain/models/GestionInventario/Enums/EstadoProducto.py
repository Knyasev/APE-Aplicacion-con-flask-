from enum import Enum

class EstadoProducto(Enum):
    BUENO   = 'BUENO'
    CADUCADO = 'CADUCADO'
    