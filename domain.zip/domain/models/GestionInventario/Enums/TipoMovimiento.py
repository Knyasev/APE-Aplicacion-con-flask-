from enum import Enum

class TipoMovimiento(Enum):
    ENTRADA = 'ENTRADA'
    SALIDA = 'SALIDA'
    AJUSTE = 'AJUSTE'